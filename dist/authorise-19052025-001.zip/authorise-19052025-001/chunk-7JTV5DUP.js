import{a}from"./chunk-C3KJNLBW.js";import"./chunk-QDSGMOWV.js";export default a();
