(function() {
  __ant_icon_load({
      name: 'twitch',
      theme: 'fill',
      icon: '<svg fill-rule="evenodd" viewBox="64 64 896 896" focusable="false"><defs><filter filterUnits="objectBoundingBox" height="102.3%" id="a" width="102.3%" x="-1.2%" y="-1.2%"><feOffset dy="2" in="SourceAlpha" result="shadowOffsetOuter1" /><feGaussianBlur in="shadowOffsetOuter1" result="shadowBlurOuter1" stdDeviation="2" /><feColorMatrix in="shadowBlurOuter1" result="shadowMatrixOuter1" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.5 0" /><feMerge><feMergeNode in="shadowMatrixOuter1" /><feMergeNode in="SourceGraphic" /></feMerge></filter></defs><g filter="url(#a)" transform="translate(9 9)"><path d="M185.14 112L128 254.86V797.7h171.43V912H413.7L528 797.71h142.86l200-200V112zm314.29 428.57H413.7V310.21h85.72zm200 0H613.7V310.21h85.72z" /></g></svg>'
  });
})()