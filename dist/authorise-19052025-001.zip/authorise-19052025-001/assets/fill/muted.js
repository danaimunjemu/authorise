(function() {
  __ant_icon_load({
      name: 'muted',
      theme: 'fill',
      icon: '<svg fill-rule="evenodd" viewBox="64 64 896 896" focusable="false"><path d="M771.91 115a31.65 31.65 0 00-17.42 5.27L400 351.97H236a16 16 0 00-16 16v288.06a16 16 0 0016 16h164l354.5 231.7a31.66 31.66 0 0017.42 5.27c16.65 0 32.08-13.25 32.08-32.06V147.06c0-18.8-15.44-32.06-32.09-32.06" /></svg>'
  });
})()