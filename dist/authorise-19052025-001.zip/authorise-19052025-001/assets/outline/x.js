(function() {
  __ant_icon_load({
      name: 'x',
      theme: 'outline',
      icon: '<svg fill-rule="evenodd" viewBox="64 64 896 896" focusable="false"><path d="M921 912L601.11 445.75l.55.43L890.08 112H793.7L558.74 384 372.15 112H119.37l298.65 435.31-.04-.04L103 912h96.39L460.6 609.38 668.2 912zM333.96 184.73l448.83 654.54H706.4L257.2 184.73z" /></svg>'
  });
})()